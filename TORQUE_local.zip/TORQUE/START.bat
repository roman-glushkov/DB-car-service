@echo off
chcp 65001 >nul
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
 echo Для запуска установите Node.js 24 LTS, затем снова откройте START.bat.
 echo https://nodejs.org
 pause
 exit /b 1
)
node server.mjs --open
pause
