import { env, getIdentity } from './runtime.mjs';
export const dynamic = 'force-dynamic';
async function carAccess(id) { const identity = await getIdentity(); if (!identity)
    return null; const user = await env.DB.prepare('SELECT * FROM users WHERE id=? OR lower(email)=lower(?)').bind(identity.userId, identity.email).first(); if (!user)
    return null; const car = await env.DB.prepare('SELECT * FROM cars WHERE id=?').bind(id).first(); if (!car)
    return null; if (user.role === 'admin' || car.owner_id === user.id)
    return car; if (user.role === 'master' && await env.DB.prepare('SELECT id FROM orders WHERE car_id=? AND master_id=?').bind(id, user.master_id).first())
    return { ...car, readonly: true }; return null; }
export async function POST(req) { try {
    const f = await req.formData();
    const id = Number(f.get('carId'));
    const car = await carAccess(id);
    if (!car || car.readonly)
        return Response.json({ error: 'Нет доступа' }, { status: 403 });
    const file = f.get('file');
    if (!(file instanceof File) || file.size > 5 * 1024 * 1024)
        return Response.json({ error: 'Выберите изображение до 5 МБ' }, { status: 400 });
    const data = await file.arrayBuffer();
    const b = new Uint8Array(data);
    const type = b[0] === 255 && b[1] === 216 && b[2] === 255 ? 'image/jpeg' : b[0] === 137 && b[1] === 80 && b[2] === 78 && b[3] === 71 ? 'image/png' : String.fromCharCode(...b.slice(0, 4)) === 'RIFF' && String.fromCharCode(...b.slice(8, 12)) === 'WEBP' ? 'image/webp' : null;
    if (!type)
        return Response.json({ error: 'Поддерживаются JPG, PNG и WebP' }, { status: 400 });
    const key = `cars/${id}/${crypto.randomUUID()}`;
    await env.BUCKET.put(key, data, { httpMetadata: { contentType: type } });
    await env.DB.prepare('UPDATE cars SET photo=? WHERE id=?').bind(key, id).run();
    if (car.photo)
        await env.BUCKET.delete(car.photo);
    return Response.json({ ok: true });
}
catch {
    return Response.json({ error: 'Не удалось загрузить фото' }, { status: 500 });
} }
export async function GET(req) { const id = Number(new URL(req.url).searchParams.get('carId')); const car = await carAccess(id); if (!car?.photo)
    return new Response(null, { status: 404 }); const file = await env.BUCKET.get(car.photo); if (!file)
    return new Response(null, { status: 404 }); return new Response(file.body, { headers: { 'Content-Type': file.httpMetadata?.contentType || 'image/jpeg', 'Cache-Control': 'private, no-cache', 'X-Content-Type-Options': 'nosniff' } }); }
