import {DatabaseSync} from 'node:sqlite';
import {AsyncLocalStorage} from 'node:async_hooks';
import {mkdirSync,readFileSync,writeFileSync,existsSync,unlinkSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const root=path.dirname(fileURLToPath(import.meta.url));
mkdirSync(path.join(root,'data','uploads'),{recursive:true});
export const sqlite=new DatabaseSync(path.join(root,'data','torque.sqlite'));
sqlite.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
if(!sqlite.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name='settings'").get())sqlite.exec(readFileSync(path.join(root,'schema.sql'),'utf8'));
export const identities={admin:{userId:'local-admin',email:'admin@torque.local',fullName:'Александр Морозов'},client:{userId:'local-client',email:'client@torque.local',fullName:'Иван Петров'},master:{userId:'local-master',email:'master@torque.local',fullName:'Дмитрий Волков'}};
export const context=new AsyncLocalStorage();
export async function getIdentity(){const role=context.getStore();return identities[role]||null;}
const DB={prepare(query){return {args:[],bind(...args){this.args=args;return this},async first(){return sqlite.prepare(query).get(...this.args)||null},async all(){return {results:sqlite.prepare(query).all(...this.args)}},runSync(){const r=sqlite.prepare(query).run(...this.args);return {meta:{last_row_id:Number(r.lastInsertRowid),changes:Number(r.changes)}}},async run(){return this.runSync()}}},async batch(statements){sqlite.exec('BEGIN IMMEDIATE');try{const r=statements.map(s=>s.runSync());sqlite.exec('COMMIT');return r}catch(e){sqlite.exec('ROLLBACK');throw e}}};
function objectPath(key){if(!/^[a-zA-Z0-9/-]+$/.test(key))throw Error('Invalid object key');return path.join(root,'data','uploads',key)}
const BUCKET={async put(key,body,opts){const dest=objectPath(key);mkdirSync(path.dirname(dest),{recursive:true});writeFileSync(dest,Buffer.from(body));writeFileSync(dest+'.json',JSON.stringify(opts.httpMetadata||{}))},async get(key){const dest=objectPath(key);if(!existsSync(dest))return null;return {body:readFileSync(dest),httpMetadata:JSON.parse(readFileSync(dest+'.json','utf8'))}},async delete(key){const dest=objectPath(key);for(const p of [dest,dest+'.json'])if(existsSync(p))unlinkSync(p)}};
export const env={DB,BUCKET};
