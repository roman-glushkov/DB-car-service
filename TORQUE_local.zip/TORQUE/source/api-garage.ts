import { env } from 'cloudflare:workers';
import { identity as getIdentity } from '../../identity';
export const dynamic='force-dynamic';
const db=()=>env.DB!;
const run=(sql:string,...args:any[])=>db().prepare(sql).bind(...args).run();
const all=async(sql:string,...args:any[])=>(await db().prepare(sql).bind(...args).all()).results as any[];
const one=async(sql:string,...args:any[])=>await db().prepare(sql).bind(...args).first() as any;
const fail=(message:string,status=400)=>Response.json({error:message},{status});
const statuses=['Принят','Диагностика','В работе','Ожидание запчастей','Готов','Выдан','Отменён'];
async function actor(){
 const identity=await getIdentity();if(!identity)return null;
 await run("INSERT INTO settings(key,value) VALUES('owner',?) ON CONFLICT(key) DO NOTHING",identity.userId);
 const owner=await one("SELECT value FROM settings WHERE key='owner'");
 const invite=await one('SELECT * FROM users WHERE lower(email)=lower(?)',identity.email);
 if(invite&&invite.id!==identity.userId)return invite;
 await run('INSERT INTO users(id,email,name,role) VALUES(?,?,?,?) ON CONFLICT(id) DO NOTHING',identity.userId,identity.email,identity.fullName||'Александр',owner.value===identity.userId?'admin':'client');
 return one('SELECT * FROM users WHERE id=?',identity.userId);
}
async function seed(u:any){
 const init=await one("SELECT value FROM settings WHERE key='demo'");if(init)return;
 const now=new Date().toISOString();const today=new Date().toLocaleDateString('sv-SE',{timeZone:'Europe/Moscow'});
 await db().batch([
 db().prepare("INSERT INTO settings(key,value) VALUES('demo','1')"),
 ...[[1,'Диагностика автомобиля',2500,60,'Диагностика'],[2,'Замена масла и фильтров',3900,60,'ТО'],[3,'Ремонт тормозной системы',6500,120,'Тормоза'],[4,'Диагностика электрики',3000,90,'Электрика'],[5,'Ремонт подвески',8000,180,'Подвеска'],[6,'Шиномонтаж',3200,60,'Колёса']].map(v=>db().prepare('INSERT INTO services(id,name,price,duration,category) VALUES(?,?,?,?,?)').bind(...v)),
 ...[[1,'Дмитрий Волков','ДВ',1,'#dce7e1'],[2,'Михаил Орлов','МО',1,'#e6dff1'],[3,'Артём Соколов','АС',1,'#f3e2cf'],[4,'Андрей Белов','АБ',1,'#dde6ed']].map(v=>db().prepare('INSERT INTO masters(id,name,initials,active,color) VALUES(?,?,?,?,?)').bind(...v)),
 ...[[1,1],[1,2],[1,3],[2,1],[2,4],[3,3],[3,5],[4,2],[4,6]].map(v=>db().prepare('INSERT INTO master_skills(master_id,service_id) VALUES(?,?)').bind(...v)),
 ...[[1,u.id,'BMW','5 серии','А 777 АА · 777',2021,68450,'Серый'],[2,u.id,'Mercedes-Benz','E-Класс','М 555 ММ · 799',2020,92100,'Чёрный'],[3,u.id,'Audi','A6','О 123 ОО · 777',2022,35200,'Белый']].map(v=>db().prepare('INSERT INTO cars(id,owner_id,brand,model,plate,year,mileage,color) VALUES(?,?,?,?,?,?,?,?)').bind(...v)),
 ...[[1048,1,2,1,'В работе','Плановое ТО, замена масла и всех фильтров',today,3900,now,1],[1047,2,4,2,'Диагностика','Периодически загорается индикатор Check Engine',today,3000,now,1],[1046,3,5,3,'Ожидание запчастей','Стук в передней подвеске на неровностях',today,8000,now,1],[1045,1,6,4,'Готов','Сезонная смена комплекта шин',today,3200,now,1],[1044,2,3,3,'Принят','Скрип при торможении',today,6500,now,1]].map(v=>db().prepare('INSERT INTO orders(id,car_id,service_id,master_id,status,complaint,date,price,created_at,demo) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(...v)),
 db().prepare('INSERT INTO events(order_id,actor,message,at) VALUES(1048,?,?,?)').bind(u.name,'Демонстрационный заказ создан',now)
 ]);
}
export async function GET(req:Request){try{
 const u=await actor();if(!u)return fail('Войдите в аккаунт',401);if(u.role==='admin')await seed(u);
 const q=new URL(req.url).searchParams;let role=u.role;if(u.role==='admin'&&['admin','master','client'].includes(q.get('view')||''))role=q.get('view');
 const mid=u.role==='admin'?Number(q.get('master')||1):u.master_id;
 const condition=role==='client'?'WHERE c.owner_id=?':role==='master'?'WHERE o.master_id=?':'';const args=role==='client'?[u.id]:role==='master'?[mid||-1]:[];
 const orders=await all(`SELECT o.*,c.brand,c.model,c.plate,c.owner_id,c.photo,u.name client_name,s.name service_name,s.category,m.name master_name,m.initials,m.color master_color FROM orders o JOIN cars c ON c.id=o.car_id JOIN users u ON u.id=c.owner_id JOIN services s ON s.id=o.service_id LEFT JOIN masters m ON m.id=o.master_id ${condition} ORDER BY o.id DESC`,...args);
 const cars=role==='admin'?await all('SELECT c.*,u.name owner_name FROM cars c JOIN users u ON u.id=c.owner_id'):role==='client'?await all('SELECT * FROM cars WHERE owner_id=?',u.id):await all('SELECT DISTINCT c.* FROM cars c JOIN orders o ON o.car_id=c.id WHERE o.master_id=?',mid||-1);
 const masters=await all('SELECT m.*,(SELECT count(*) FROM orders o WHERE o.master_id=m.id AND o.status NOT IN (\'Готов\',\'Выдан\',\'Отменён\')) load FROM masters m');
 const events=orders.length?await all(`SELECT e.* FROM events e WHERE e.order_id IN (${orders.map(()=>'?').join(',')}) ORDER BY e.id DESC LIMIT 30`,...orders.map(o=>o.id)):[];
 return Response.json({user:u,view:role,orders,cars,masters,services:await all('SELECT * FROM services'),skills:await all('SELECT * FROM master_skills'),users:u.role==='admin'?await all('SELECT * FROM users'):[],events,statuses});
 }catch(e){console.error(e);return fail('Не удалось загрузить данные. Попробуйте ещё раз.',500)}}
export async function POST(req:Request){try{
 const u=await actor();if(!u)return fail('Войдите в аккаунт',401);
 const b:any=await req.json();const admin=u.role==='admin';const now=new Date().toISOString();const str=(x:any,max=1000)=>String(x||'').trim().slice(0,max);const int=(x:any)=>Number.isSafeInteger(Number(x))?Number(x):0;
 if(b.action==='createOrder'){
 const car=await one('SELECT * FROM cars WHERE id=?',int(b.carId));if(!car||(!admin&&car.owner_id!==u.id)||u.role==='master')return fail('Нет доступа к автомобилю',403);
 const s=await one('SELECT * FROM services WHERE id=?',int(b.serviceId));if(!s)return fail('Выберите услугу');if(str(b.complaint).length<5)return fail('Опишите проблему: минимум 5 символов');if(!/^\d{4}-\d{2}-\d{2}$/.test(b.date)||!Number.isFinite(Date.parse(b.date))||b.date<new Date().toLocaleDateString('sv-SE',{timeZone:'Europe/Moscow'}))return fail('Выберите сегодняшнюю или будущую дату');
 const result=await run(`INSERT INTO orders(car_id,service_id,master_id,status,complaint,date,price,created_at) VALUES(?,?,(SELECT m.id FROM masters m JOIN master_skills k ON k.master_id=m.id WHERE k.service_id=? AND m.active=1 ORDER BY (SELECT count(*) FROM orders o WHERE o.master_id=m.id AND o.status NOT IN ('Готов','Выдан','Отменён')),m.id LIMIT 1),'Принят',?,?,?,?)`,car.id,s.id,s.id,str(b.complaint),b.date,s.price,now);
 await run('INSERT INTO events(order_id,actor,message,at) VALUES(?,?,?,?)',result.meta.last_row_id,u.name,'Заказ создан. Выполнен подбор мастера по навыку и загрузке.',now);return Response.json({ok:true,id:result.meta.last_row_id});
 }
 if(b.action==='saveCar'){
 const id=int(b.id);if(u.role==='master')return fail('Нет доступа',403);if(!str(b.brand,60)||!str(b.model,60)||!str(b.plate,25)||int(b.year)<1886||int(b.year)>2100||int(b.mileage)<0)return fail('Проверьте данные автомобиля');
 if(id){const car=await one('SELECT * FROM cars WHERE id=?',id);if(!car||(!admin&&car.owner_id!==u.id))return fail('Нет доступа',403);await run('UPDATE cars SET brand=?,model=?,plate=?,year=?,mileage=?,color=? WHERE id=?',str(b.brand,60),str(b.model,60),str(b.plate,25),int(b.year),int(b.mileage),str(b.color,40),id);}else await run('INSERT INTO cars(owner_id,brand,model,plate,year,mileage,color) VALUES(?,?,?,?,?,?,?)',admin&&b.ownerId?b.ownerId:u.id,str(b.brand,60),str(b.model,60),str(b.plate,25),int(b.year),int(b.mileage),str(b.color,40));
 }else if(b.action==='updateOrder'){
 const o=await one('SELECT * FROM orders WHERE id=?',int(b.id));if(!o||(!admin&&(u.role!=='master'||o.master_id!==u.master_id)))return fail('Нет доступа к заказу',403);
 if(admin&&(!/^\d{4}-\d{2}-\d{2}$/.test(b.date)||!Number.isFinite(Date.parse(b.date))||str(b.complaint).length<5))return fail('Проверьте дату и описание проблемы');
 const status=str(b.status);if(!statuses.includes(status))return fail('Некорректный статус');
 let mid=o.master_id;if(admin){mid=int(b.masterId)||null;if(mid){const match=await one('SELECT m.id FROM masters m JOIN master_skills k ON k.master_id=m.id WHERE m.id=? AND k.service_id=? AND m.active=1',mid,o.service_id);if(!match)return fail('Мастер не активен или не имеет нужного навыка');}}
 if(admin&&(!Number.isFinite(Number(b.price))||Number(b.price)<0||Number(b.price)>10000000))return fail('Некорректная стоимость');
 await db().batch([db().prepare('UPDATE orders SET status=?,master_id=?,diagnosis=?,price=?,complaint=?,date=? WHERE id=?').bind(status,mid,str(b.diagnosis,3000),admin?Math.round(Number(b.price)):o.price,admin?str(b.complaint):o.complaint,admin?str(b.date,10):o.date,o.id),db().prepare('INSERT INTO events(order_id,actor,message,at) VALUES(?,?,?,?)').bind(o.id,u.name,`Статус: ${status}${mid!==o.master_id?' · Мастер переназначен':''}`,now)]);
 }else if(b.action==='deleteOrder'&&admin){await run('DELETE FROM events WHERE order_id=?',int(b.id));await run('DELETE FROM orders WHERE id=?',int(b.id));
 }else if(b.action==='saveMaster'&&admin){
 const ids=[...new Set((b.skills||[]).map(int))] as number[];if(!str(b.name,100)||!ids.length)return fail('Укажите имя и хотя бы один навык');const valid=await all('SELECT id FROM services');if(ids.some(id=>!valid.some(s=>s.id===id)))return fail('Неизвестный навык');let id=int(b.id);
 if(id){await run('UPDATE masters SET name=?,initials=?,active=? WHERE id=?',str(b.name,100),str(b.name).split(' ').map((s:string)=>s[0]).slice(0,2).join(''),b.active?1:0,id);}else{const r=await run('INSERT INTO masters(name,initials,active) VALUES(?,?,?)',str(b.name,100),str(b.name).split(' ').map((s:string)=>s[0]).slice(0,2).join(''),b.active?1:0);id=r.meta.last_row_id;}
 await db().batch([db().prepare('DELETE FROM master_skills WHERE master_id=?').bind(id),...ids.map(sid=>db().prepare('INSERT INTO master_skills(master_id,service_id) VALUES(?,?)').bind(id,sid))]);
 }else if(b.action==='saveService'&&admin){if(!str(b.name)||int(b.price)<0||int(b.duration)<1)return fail('Проверьте услугу');if(int(b.id))await run('UPDATE services SET name=?,price=?,duration=?,category=? WHERE id=?',str(b.name,100),int(b.price),int(b.duration),str(b.category,60),int(b.id));else await run('INSERT INTO services(name,price,duration,category) VALUES(?,?,?,?)',str(b.name,100),int(b.price),int(b.duration),str(b.category,60));
 }else if(b.action==='saveUser'&&admin){
 if(!str(b.name)||!/^\S+@\S+\.\S+$/.test(b.email)||!['client','master','admin'].includes(b.role))return fail('Проверьте имя, email и роль');if(b.id===u.id&&b.role!=='admin')return fail('Нельзя снять права с текущего администратора');if(b.role==='master'&&!(await one('SELECT id FROM masters WHERE id=?',int(b.masterId))))return fail('Выберите профиль мастера');
 const id=b.id||crypto.randomUUID();await run('INSERT INTO users(id,email,name,role,master_id) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,email=excluded.email,role=excluded.role,master_id=excluded.master_id',id,str(b.email,200).toLowerCase(),str(b.name,100),b.role,b.role==='master'?int(b.masterId):null);
 }else return fail('Действие недоступно',403);
 return Response.json({ok:true});
 }catch(e){console.error(e);return fail('Изменения не сохранены. Проверьте данные и повторите.',400)}}
