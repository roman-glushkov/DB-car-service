// Optional: only needed after editing source/app.tsx.
// npm install --no-save esbuild react react-dom lucide-react
import {build} from 'esbuild';
import {copyFileSync} from 'node:fs';
await build({entryPoints:['source/app.tsx'],bundle:true,minify:true,jsx:'automatic',define:{'process.env.NODE_ENV':'"production"'},outfile:'assets/app.js',platform:'browser',target:'es2022'});
copyFileSync('source/globals.css','assets/app.css');
console.log('Frontend rebuilt. Run node server.mjs.');
